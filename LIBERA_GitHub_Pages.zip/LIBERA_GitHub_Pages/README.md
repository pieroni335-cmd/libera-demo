# LIBERA — prototipo web 1.2

Prototipo sperimentale di comunicazione CAA e attività quotidiane, con sintesi vocale tramite Web Speech API.

## Pubblicazione su GitHub Pages

1. Crea un repository **pubblico** su GitHub (per esempio `libera-demo`).
2. Carica `index.html` e `.nojekyll` nella radice del repository, tramite **Add file → Upload files → Commit changes**.
3. Apri **Settings → Pages**. In **Build and deployment**, scegli **Deploy from a branch**; seleziona `main` e `/ (root)`; salva.
4. Attendi la pubblicazione e apri l'indirizzo indicato da GitHub Pages (di solito `https://TUO-UTENTE.github.io/libera-demo/`) in Safari o Chrome.
5. Tocca **Prova voce**. La sintesi vocale dipende dalle voci installate e dal browser.

## Avvertenze

- Il repository pubblico rende **visibile a chiunque il codice**. Non caricare dati personali, credenziali o informazioni sensibili.
- Le frasi personalizzate e le preferenze vengono salvate nel browser tramite `localStorage`, non su un server. Non sono sincronizzate e possono essere cancellate dal browser.
- Il prototipo non è stato certificato come ausilio di comunicazione né sottoposto a verifica completa di accessibilità.
- La sintesi vocale può essere limitata dal browser, dalle impostazioni del dispositivo e dalle voci disponibili.
